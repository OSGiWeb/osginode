#ifndef WINDOWWIDGETPLUGIN_H
#define WINDOWWIDGETPLUGIN_H

#include <QWidget>
#include "com_plugins__Export.h"
#include "IWidgetPlugin.h"

class com_plugins__Export WindowWidgetPlugin: public IWidgetPlugin
{
    Q_OBJECT

public:
    WindowWidgetPlugin();
    virtual ~WindowWidgetPlugin();

    /* Plugin interfaces */
    QList<ICenterWindow*> getCenterWindow();
    QList<ISettingWindow*> getSettingWindow();
    QList<IPluginInfo*> getPluginInfoWindow();
    
private:
    QList<ICenterWindow*> m_centerWindowList;
    QList<ISettingWindow*> m_settingWindowList;
    QList<IPluginInfo*> m_pluginInfoList;

    void createWidget();
};

#endif // WINDOWWIDGETPLUGIN_H
