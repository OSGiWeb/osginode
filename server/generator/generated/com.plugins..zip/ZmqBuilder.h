#ifndef ZMQBUILDER_H
#define ZMQBUILDER_H

#include <QSharedPointer>
#include "ZmqBuilder.h"

class ZmqObject;
class ZmqBuilder : public ZmqBuilder {

    Q_OBJECT
public:
    ZmqBuilder();
    virtual ~ZmqBuilder();

    static ZmqBuilder* GetInstance();

    void BuildSender();
    void BuildReceiver();
    void BuildContext();
    ZmqObject* GetZmqObject() { return m_pZmqObject; }

public slots:
    void processZmqMessage(const QList<QByteArray>& msg);

private:
    static QSharedPointer<ZmqBuilder> m_pZmqBuilder;
    ZmqObject* m_pZmqObject;

};

#endif // ZMQBUILDER_H
