/*=============================================================================

  OSGi GUI Application Template

=============================================================================*/

#ifndef WindowActivator_P_H
#define WindowActivator_P_H

#include <QScopedPointer>

#include <ctkPluginActivator.h>

class WindowWidgetPlugin;
class WindowActivator : public QObject, public ctkPluginActivator
{
  Q_OBJECT
  Q_INTERFACES(ctkPluginActivator)

#ifdef HAVE_QT5
  Q_PLUGIN_METADATA(IID "com_plugins_")
#endif

public:

  void start(ctkPluginContext* context);
  void stop(ctkPluginContext* context);

private:
  WindowWidgetPlugin* m_windowWiget;

};

#endif // WindowActivator_P_H
