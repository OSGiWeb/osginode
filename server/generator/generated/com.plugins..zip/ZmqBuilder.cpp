#include <QDebug>
#include "ZmqObject.h"
#include "ZmqBuilder.h"
#include "ZmqManagement.h"
#include "ZmqDirector.h"
/* (TODO) Include user receive polling process header */

/////////////////////////////////////////////////////////////////////////////////
// Singleton Access
/////////////////////////////////////////////////////////////////////////////////
QSharedPointer<ZmqBuilder> ZmqBuilder::m_pZmqBuilder;
ZmqBuilder* ZmqBuilder::GetInstance() {

    if(m_pZmqBuilder.isNull()) {
        ZmqDirector m_director;
        m_pZmqBuilder = QSharedPointer<ZmqBuilder>(new ZmqBuilder());
        m_director.Construct(*(m_pZmqBuilder.data()));
    }
    return m_pZmqBuilder.data();
}

ZmqBuilder::ZmqBuilder() {
    ZMQContext* context = ZmqManagement::GetInstance()->getZeroMQContext();
    m_pZmqObject = new ZmqObject(context);
}

ZmqBuilder::~ZmqBuilder() {

}

void ZmqBuilder::BuildSender() {
    m_pZmqObject->createSender(ZMQSocket::TYP_PUSH, "inproc://pushpull(ALL2CMW)", "RMD2CMW");
}

void ZmqBuilder::BuildReceiver() {
	/**
	* (TODO) Connect zmq to user polling receive process function, e.g.:
	*  		m_pZmqObject->createReceiver(ZMQSocket::TYP_SUB, "inproc://pubsub(CMW2ALL)", "CMW2RMD",
    *                     this, SLOT(processZmqMessage(const QList<QByteArray>&)));
	**/

}

void ZmqBuilder::BuildContext() {
    m_pZmqObject->startContext();
}

void ZmqBuilder::processZmqMessage(const QList<QByteArray>& msg) {
    qDebug()<<"[] received message from ZMQ socket!";

    QByteArray ba = msg.at(1); // Data in 2nd place
	
	/**
	* (TODO) Invoke user polling receive process function, e.g.:
	*  			NetDataProcess::getInstance()->processNetworkData(ba.data(), ba.length(), "CMW2RMD");
	**/
}
