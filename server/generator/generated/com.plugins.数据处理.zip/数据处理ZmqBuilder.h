#ifndef 数据处理ZMQBUILDER_H
#define 数据处理ZMQBUILDER_H

#include <QSharedPointer>
#include "ZmqBuilder.h"

class ZmqObject;
class 数据处理ZmqBuilder : public ZmqBuilder {

    Q_OBJECT
public:
    数据处理ZmqBuilder();
    virtual ~数据处理ZmqBuilder();

    static 数据处理ZmqBuilder* GetInstance();

    void BuildSender();
    void BuildReceiver();
    void BuildContext();
    ZmqObject* GetZmqObject() { return m_pZmqObject; }

public slots:
    void processZmqMessage(const QList<QByteArray>& msg);

private:
    static QSharedPointer<数据处理ZmqBuilder> m_p数据处理ZmqBuilder;
    ZmqObject* m_pZmqObject;

};

#endif // 数据处理ZMQBUILDER_H
