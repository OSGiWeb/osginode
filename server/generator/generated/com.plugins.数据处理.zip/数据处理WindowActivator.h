/*=============================================================================

  OSGi GUI Application Template

=============================================================================*/

#ifndef 数据处理WindowActivator_P_H
#define 数据处理WindowActivator_P_H

#include <QScopedPointer>

#include <ctkPluginActivator.h>

class 数据处理WindowWidgetPlugin;
class 数据处理WindowActivator : public QObject, public ctkPluginActivator
{
  Q_OBJECT
  Q_INTERFACES(ctkPluginActivator)

#ifdef HAVE_QT5
  Q_PLUGIN_METADATA(IID "com_plugins_数据处理")
#endif

public:

  void start(ctkPluginContext* context);
  void stop(ctkPluginContext* context);

private:
  数据处理WindowWidgetPlugin* m_windowWiget;

};

#endif // 数据处理WindowActivator_P_H
