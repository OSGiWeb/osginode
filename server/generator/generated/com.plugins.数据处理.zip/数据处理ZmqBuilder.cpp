#include <QDebug>
#include "ZmqObject.h"
#include "数据处理ZmqBuilder.h"
#include "ZmqManagement.h"
#include "ZmqDirector.h"
/* (TODO) Include user receive polling process header */

/////////////////////////////////////////////////////////////////////////////////
// Singleton Access
/////////////////////////////////////////////////////////////////////////////////
QSharedPointer<数据处理ZmqBuilder> 数据处理ZmqBuilder::m_p数据处理ZmqBuilder;
数据处理ZmqBuilder* 数据处理ZmqBuilder::GetInstance() {

    if(m_p数据处理ZmqBuilder.isNull()) {
        ZmqDirector m_director数据处理;
        m_p数据处理ZmqBuilder = QSharedPointer<数据处理ZmqBuilder>(new 数据处理ZmqBuilder());
        m_director数据处理.Construct(*(m_p数据处理ZmqBuilder.data()));
    }
    return m_p数据处理ZmqBuilder.data();
}

数据处理ZmqBuilder::数据处理ZmqBuilder() {
    ZMQContext* context = ZmqManagement::GetInstance()->getZeroMQContext();
    m_pZmqObject = new ZmqObject(context);
}

数据处理ZmqBuilder::~数据处理ZmqBuilder() {

}

void 数据处理ZmqBuilder::BuildSender() {
    m_pZmqObject->createSender(ZMQSocket::TYP_PUSH, "inproc://pushpull(ALL2CMW)", "RMD2CMW");
}

void 数据处理ZmqBuilder::BuildReceiver() {
	/**
	* (TODO) Connect zmq to user polling receive process function, e.g.:
	*  		m_pZmqObject->createReceiver(ZMQSocket::TYP_SUB, "inproc://pubsub(CMW2ALL)", "CMW2RMD",
    *                     this, SLOT(processZmqMessage(const QList<QByteArray>&)));
	**/

}

void 数据处理ZmqBuilder::BuildContext() {
    m_pZmqObject->startContext();
}

void 数据处理ZmqBuilder::processZmqMessage(const QList<QByteArray>& msg) {
    qDebug()<<"[数据处理] received message from ZMQ socket!";

    QByteArray ba = msg.at(1); // Data in 2nd place
	
	/**
	* (TODO) Invoke user polling receive process function, e.g.:
	*  			NetDataProcess::getInstance()->processNetworkData(ba.data(), ba.length(), "CMW2RMD");
	**/
}
