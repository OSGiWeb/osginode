#ifndef 数据处理WINDOWWIDGETPLUGIN_H
#define 数据处理WINDOWWIDGETPLUGIN_H

#include <QWidget>
#include "com_plugins_数据处理_Export.h"
#include "IWidgetPlugin.h"

class com_plugins_数据处理_Export 数据处理WindowWidgetPlugin: public IWidgetPlugin
{
    Q_OBJECT

public:
    数据处理WindowWidgetPlugin();
    virtual ~数据处理WindowWidgetPlugin();

    /* Plugin interfaces */
    QList<ICenterWindow*> getCenterWindow();
    QList<ISettingWindow*> getSettingWindow();
    QList<IPluginInfo*> getPluginInfoWindow();
    
private:
    QList<ICenterWindow*> m_centerWindowList;
    QList<ISettingWindow*> m_settingWindowList;
    QList<IPluginInfo*> m_pluginInfoList;

    void createWidget();
};

#endif // WINDOWWIDGETPLUGIN_H
